"""FAST Cloud application package."""
